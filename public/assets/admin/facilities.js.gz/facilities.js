
$(function () {
    $("#facility_check_all").change(function () {
        if ($(this).is(':checked')) {
            $(".facility_id_checkbox").attr("checked", "checked");
        } else {
            $(".facility_id_checkbox").removeAttr("checked");
        }
    });
});

