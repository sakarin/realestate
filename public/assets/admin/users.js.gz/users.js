(function() {

  $('#user_birth_date_1i').addClass("span2");

  $('#user_birth_date_2i').addClass("span3");

  $('#user_birth_date_3i').addClass("span2");

}).call(this);
